# fraction/__init__.py

from .fraction import Fraction
