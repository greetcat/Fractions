# Fraction Package

A simple fraction data type for Python.
